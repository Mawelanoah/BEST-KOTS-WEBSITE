# 1.BEST KOTA Website

Free static website for 1.BEST KOTA.

## Files
- index.html
- style.css
- script.js
- assets/logo.webp

## Contact
WhatsApp: 072 147 1679
Address: 5242 MMupuru Street
Hours: 07:00 - 19:00

## Free hosting
No server needed — it's a static site. Free options:
- GitHub Pages (github.io)
- Netlify (drag-and-drop the folder at app.netlify.com/drop)
- Cloudflare Pages

Just upload these files and the site is live at no cost.
